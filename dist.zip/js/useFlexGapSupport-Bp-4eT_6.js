import{aP as a}from"./bootstrap-CPnRZazZ.js";import{a5 as o,a9 as t}from"../jse/index-index-DUSCGC6b.js";const s=()=>{const e=o(!1);return t(()=>{e.value=a()}),e};export{s as u};
